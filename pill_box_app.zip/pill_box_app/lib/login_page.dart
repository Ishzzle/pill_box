import 'package:flutter/material.dart';
import 'package:pill_box_app/authentication_service.dart';
import 'package:pill_box_app/menu_navigation.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:pill_box_app/sign_up.dart';
import 'package:provider/provider.dart';

class Login extends StatelessWidget {
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  //const Login({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context)  {
    return Scaffold(
      body: Column(
        children: [
          Container(
            child: Image(
              image: AssetImage('assets/login_graphic.png'),
            ),
          ),

          Expanded(
            flex: 60,
            child: Column(
              children: [
                Container(
                  margin: EdgeInsets.only(top: 10, bottom: 10),
                  child: Text('Login',
                    style: TextStyle(
                        fontSize: 28,
                        color: Colors.black
                    ),

                  ),
                ),
                Container(
                  margin: EdgeInsets.only(left: 15, right: 15, bottom:15),
                  child: TextField(
                    obscureText: false,
                    controller: emailController,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: 'Email Address',
                    ),
                  ),
                ),
                Container(
                  margin: EdgeInsets.only(left: 15, right: 15, bottom:0),
                  child: TextField(
                    obscureText: true,
                    controller: passwordController,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: 'Password',
                    ),
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text('Don\'t have an account?'),
                    TextButton(
                      style: TextButton.styleFrom(
                        textStyle: TextStyle(fontSize: 15 ),

                      ),
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(builder: (context) => SignUp()));
                      },
                      child: Text('Sign up!'),
                    ),
                  ],
                ),

                RaisedButton(
                  child: Text("Sign in"),
                    onPressed: (){
                      context.read<AuthenicationService>().signIn(
                          email: emailController.text.trim(),
                          password: passwordController.text.trim()
                      );
                    }
                )
              ],
            ),
          )
        ],
      ),
    );
  }
}