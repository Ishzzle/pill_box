import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';

class med{
  final String title;
  med({required this.title});

  String toString() => this.title;
}