import 'package:flutter/material.dart';
import 'package:pill_box_app/authentication_service.dart';
import 'package:pill_box_app/misc/event_provider.dart';
import 'package:pill_box_app/newEvent.dart';
import 'package:provider/provider.dart';
import 'package:syncfusion_flutter_calendar/calendar.dart';
import 'package:table_calendar/table_calendar.dart';
import 'misc/appointment_editing.dart';
import 'misc/appointment_view.dart';
import 'medicine.dart';

class mainMenu extends StatefulWidget {
  const mainMenu({Key? key}) : super(key: key);

  @override
  State<mainMenu> createState() => _mainMenuState();
}

class MeetingDataSource extends CalendarDataSource{
  MeetingDataSource(List<Appointment> source){
    appointments = source;
  }
}

class _mainMenuState extends State<mainMenu> {
  int _index = 0;
  Map<DateTime,List<newEvent>> selectedEvents ={};
  Map<DateTime,List<med>> selectedMed ={};
  CalendarFormat format = CalendarFormat.month;
  CalendarFormat mformat = CalendarFormat.week;
  DateTime selectedDay = DateTime.now();
  DateTime focusedDay = DateTime.now();

  TextEditingController _eventController = TextEditingController();
  TextEditingController _medicineController = TextEditingController();

  @override
  void initState(){
    selectedEvents = {};
    selectedMed = {};
    super.initState();
  }

  List<newEvent> _getEventsFromDay(DateTime date){
    return selectedEvents[date] ?? [];
  }

  List<med> _getmedFromDay(DateTime date){
    return selectedMed[date] ?? [];
  }

  @override
  void dispose(){
    _eventController.dispose();
    super.dispose();
  }

  Future<bool> _onWillPop() async {
    return false;
  }

  void _onItemTapped(int index) {
    setState(() {
      _index = index;
    });
  }

  @override
  Widget build(BuildContext context)  {
    return WillPopScope(
      onWillPop: _onWillPop,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('PillBox'),
          centerTitle: true,
        ),
        body: IndexedStack(
          index: _index,
          children: [
           Scaffold(
             body: Column(
               children: [
                 TableCalendar(
                     focusedDay: focusedDay,
                     firstDay: DateTime(1990),
                     lastDay: DateTime(2100),
                   calendarFormat: format,
                   onFormatChanged: (CalendarFormat _format){
                       setState(){
                         format = _format;
                       }
                   },
                   onDaySelected: (DateTime selectDay, DateTime focusDay){
                       setState((){
                         selectedDay = selectDay;
                         focusedDay = focusDay;
                    });
                       //print(focusDay);
                  },
                   selectedDayPredicate: (DateTime date){
                       return isSameDay(selectedDay, date);
                   },

                   eventLoader:  _getEventsFromDay,


                   calendarStyle: CalendarStyle(
                     isTodayHighlighted: true,
                     selectedDecoration: BoxDecoration(
                       color: Colors.lightGreen,
                       shape: BoxShape.circle,
                     )
                   ),
                   headerStyle: HeaderStyle(formatButtonVisible: false),
                 ),
                 ..._getEventsFromDay(selectedDay).map((newEvent event) => ListTile(title: Text(event.title))),
               ],
             ),
             floatingActionButton: FloatingActionButton.extended(
                 onPressed: () => showDialog(context: context,
                     builder: (context) => AlertDialog(
                       title: Text("Add Appointment"), content: TextFormField(controller: _eventController),
                       actions: [TextButton(child: Text("Ok"), onPressed: () {
                         if (_eventController.text.isEmpty){
                           return;
                         }else{
                           if (selectedEvents[selectedDay]!=null){
                             selectedEvents[selectedDay]?.add(
                               newEvent(title: _eventController.text),
                             );
                           } else{
                             selectedEvents[selectedDay] = [
                               newEvent(title: _eventController.text)
                             ];
                           }

                         }
                         Navigator.pop(context);
                         _eventController.clear();
                         setState((){});
                         return;
                       },
                       ),
                         TextButton(child: Text("Cancel"), onPressed: () => Navigator.pop(context),)
                       ],
                     )
                 ),
                 label:Text('Add Appointment') ,
                 icon: Icon(Icons.add),
             )
           ),



            Scaffold(
                body: Column(
                  children: [
                    TableCalendar(
                      focusedDay: focusedDay,
                      firstDay: DateTime(1990),
                      lastDay: DateTime(2100),
                      calendarFormat: mformat,
                      onFormatChanged: (CalendarFormat _format){
                        setState(){
                          mformat = _format;
                        }
                      },
                      onDaySelected: (DateTime selectDay, DateTime focusDay){
                        setState((){
                          selectedDay = selectDay;
                          focusedDay = focusDay;
                        });
                        //print(focusDay);
                      },
                      selectedDayPredicate: (DateTime date){
                        return isSameDay(selectedDay, date);
                      },

                      eventLoader:  _getmedFromDay,


                      calendarStyle: CalendarStyle(
                          isTodayHighlighted: true,
                          selectedDecoration: BoxDecoration(
                            color: Colors.lightGreen,
                            shape: BoxShape.circle,
                          )
                      ),
                      headerStyle: HeaderStyle(formatButtonVisible: false),
                    ),
                    ..._getmedFromDay(selectedDay).map((med Med) => ListTile(title: Text(Med.title))),
                  ],
                ),
                floatingActionButton: FloatingActionButton.extended(
                  onPressed: () => showDialog(context: context,
                      builder: (context) => AlertDialog(
                        title: Text("Add Medication and Time"), content: TextFormField(controller: _medicineController),
                        actions: [TextButton(child: Text("Ok"), onPressed: () {
                          if (_medicineController.text.isEmpty){
                            return;
                          }else{
                            if (selectedMed[selectedDay]!=null){
                              selectedMed[selectedDay]?.add(
                                med(title: _medicineController.text),
                              );
                            } else{
                              selectedMed[selectedDay] = [
                                med(title: _medicineController.text)
                              ];
                            }

                          }
                          Navigator.pop(context);
                          _medicineController.clear();
                          setState((){});
                          return;
                        },
                        ),
                          TextButton(child: Text("Cancel"), onPressed: () => Navigator.pop(context),)
                        ],
                      )
                  ),
                  label:Text('Add Medication') ,
                  icon: Icon(Icons.add),
                )
            ),
            Scaffold(
              body: Center(
                  child: (
                      RaisedButton(
                          child:  Text('Log Out'),
                          onPressed: (){
                            context.read<AuthenicationService>().signOut();
                          }
                      )
                  )
              ),
            ),
          ],
        ),
        bottomNavigationBar: BottomNavigationBar(
          items: const <BottomNavigationBarItem>[
            BottomNavigationBarItem(
              icon: Icon(Icons.calendar_today_outlined),
              label: 'Appointments',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.medication_outlined),
              label: 'Medication',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.person_outline_rounded),
              label: 'Profile',
            ),
          ],
          currentIndex: _index,
          onTap: _onItemTapped,
        ),
      ),
    );
  }
}
