import 'package:flutter/material.dart';
import 'package:pill_box_app/misc/app_utils.dart';
import 'package:provider/provider.dart';
import '../event.dart';
import 'event_provider.dart';

class AppointmentEdit extends StatefulWidget {
  final Event? event;

  const AppointmentEdit({
    Key? key,
    this.event,}) : super(key: key);

  @override
  State<AppointmentEdit> createState() => _AppointmentEditState();
}

class _AppointmentEditState extends State<AppointmentEdit> {
  final _formKey = GlobalKey<FormState>();
  final titleController = TextEditingController();
  late DateTime fromDate;
  late DateTime toDate;

  @override
  void initState() {
    super.initState();

    if (widget.event == null) {
      fromDate = DateTime.now();
      toDate = DateTime.now().add(Duration(hours: 2));
    }
  }

  @override
  void dispose(){
    titleController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) =>Scaffold(
    appBar: AppBar(
      leading: CloseButton(),
      actions: buildEditingActions(),
    ),
    body: SingleChildScrollView(
      padding: EdgeInsets.all(12),
      child: Form(
        key: _formKey,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            buildTitle(),
            SizedBox(height: 10),
            buildDateTimePickers(),
          ],
        ),
      ),
    ),
  );


    List<Widget> buildEditingActions() => [
          ElevatedButton.icon(
            style: ElevatedButton.styleFrom(
              primary: Colors.lightGreen,
              shadowColor: Colors.lightGreen
            ),
            onPressed: () {
              saveForm();
              },
            icon: Icon(Icons.done),
            label: Text('Confirm'),
          )
        ];
    Widget buildTitle() => TextFormField(
      style: TextStyle(fontSize: 20),
      decoration: InputDecoration(
        border: UnderlineInputBorder(),
        hintText: 'Appointment Name',
      ),
      onFieldSubmitted: (_) => saveForm(),
      validator: (title) =>
        title != null && title.isEmpty? 'Please provide appointment name': null,
      controller: titleController,
    );

    Widget buildDateTimePickers() => Column(
      children: [
        buildFrom(),
        buildTo(),
      ],
    );
    Widget buildFrom() => buildHeader(
      header: 'FROM',
      child: Row(
        children: [
          Expanded(
            flex: 2,
              child: buildDropdownField(
                text: Utils.toDate(fromDate),
                onClicked: () => pickFromDateTime(pickDate: true),
              ),
          ),
          Expanded(
            child: buildDropdownField(
                text: Utils.toTime(fromDate),
                onClicked: ()=> pickFromDateTime(pickDate: false),
            ),
          )
        ],
      ),
    );
  Widget buildTo() => buildHeader(
    header: 'TO',
    child: Row(
      children: [
        Expanded(
          flex: 2,
          child: buildDropdownField(
              text: Utils.toDate(toDate),
              onClicked: () => pickToDateTime(pickDate: true),
          ),
        ),
        Expanded(
          child: buildDropdownField(
              text: Utils.toTime(toDate),
              onClicked: ()=> pickToDateTime(pickDate: false),
          ),
        )
      ],
    ),
  );

  Future pickFromDateTime({required bool pickDate}) async{
    final date = await pickDateTime(fromDate, pickDate: pickDate);
    if (date == null) return;
    
    if (date.isAfter(toDate)){
      toDate = DateTime(date.year, date.month, date.day, toDate.hour, toDate.minute);
    }

    setState(() => fromDate = date);
  }
  Future pickToDateTime({required bool pickDate}) async{
    final date = await pickDateTime(toDate, pickDate: pickDate, firstDate: pickDate ?  fromDate: null);
    if (date == null) return;

    setState(() => toDate = date);
  }

  Future<DateTime?> pickDateTime(
      DateTime intialDate, {
        required bool pickDate,
        DateTime? firstDate,
}) async{
    if(pickDate){
      final date = await showDatePicker(
        context:  context,
        initialDate: intialDate,
        firstDate:  firstDate ?? DateTime(2015,8),
        lastDate: DateTime(2101)
      );
      if (date == null) return null;

      final time = Duration(hours: intialDate.hour,minutes: intialDate.minute);

      return date.add(time);
    } else{
      final timeOfDay = await showTimePicker(
          context: context,
          initialTime: TimeOfDay.fromDateTime(intialDate),
      );
      if (timeOfDay == null) return null;
      
      final date = 
          DateTime(intialDate.year, intialDate.month, intialDate.day);
      final time = Duration(hours: timeOfDay.hour, minutes: timeOfDay.minute);

      return date.add(time);
    }
  }

    Widget buildDropdownField({
      required String text,
      required VoidCallback onClicked,
    })  =>
        ListTile(
          title: Text(text),
          trailing: Icon(Icons.arrow_drop_down),
          onTap: onClicked,
        );
    Widget buildHeader({
      required String header,
      required Widget child,
}) => Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(header,style: TextStyle(fontWeight: FontWeight.bold),),
        child,
      ],
    );
    Future saveForm() async{
      final isValid = _formKey.currentState!.validate();
      if(isValid){
        final event = Event(
            title: titleController.text,
            description: 'Description',
            from: fromDate,
            to: toDate);
        final provider = Provider.of<EventProvider>(context, listen: false);
        provider.addEvent(event);
        Navigator.of(context).pop();
      }
    }
}

