import 'package:flutter/material.dart';


  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'PillBox',
  );


class View extends StatelessWidget {
  Widget build(BuildContext context) =>
      Scaffold(
        appBar: AppBar(
          title: Text('PillBox'),
          centerTitle: true,
        ),
      );
}


