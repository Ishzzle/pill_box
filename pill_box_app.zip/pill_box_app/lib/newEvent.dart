import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';

class newEvent{
  final String title;
  newEvent({required this.title});

  String toString() => this.title;
}