import 'package:flutter/material.dart';
import 'package:pill_box_app/login_page.dart';
import 'package:provider/provider.dart';

import 'authentication_service.dart';

class SignUp extends StatelessWidget {
  //const SignUp({Key? key}) : super(key: key);
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Container(
            child: Image(
              image: AssetImage('assets/login_graphic.png'),
            ),
          ),

          Expanded(
            flex: 60,
            child: Column(
              children: [
                Container(
                  margin: EdgeInsets.only(top: 10, bottom: 10),
                  child: Text('Sign Up',
                    style: TextStyle(
                        fontSize: 28,
                        color: Colors.black
                    ),

                  ),
                ),
                Container(
                  margin: EdgeInsets.only(left: 15, right: 15, bottom:15),
                  child: TextField(
                    obscureText: false,
                    controller: emailController,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: 'Email Address',
                    ),
                  ),
                ),
                Container(
                  margin: EdgeInsets.only(left: 15, right: 15, bottom:0),
                  child: TextField(
                    obscureText: true,
                    controller: passwordController,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: 'Password',
                    ),
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text('Already have an account?'),
                    TextButton(
                      style: TextButton.styleFrom(
                        textStyle: TextStyle(fontSize: 15 ),

                      ),
                      onPressed: () {
                      },
                      child: Text('Log in!'),
                    ),
                  ],
                ),

                RaisedButton(
                    child: Text("Sign up"),
                    onPressed: (){
                      context.read<AuthenicationService>().signUp(
                          email: emailController.text.trim(),
                          password: passwordController.text.trim()
                      );
                      Navigator.pop(
                          context,
                          MaterialPageRoute(builder: (context) => Login()));
                    }
                )
              ],
            ),
          )
        ],
      ),
    );
  }
}

